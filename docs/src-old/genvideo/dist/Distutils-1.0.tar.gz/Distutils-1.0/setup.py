#!/usr/bin env python

from distutils.core import setup

setup( name='Distutils',
	version='1.0',
	description='Python module for generate vídeo.',
	author='Wandeson Ricardo (WSRicardo)',
	author_email='',
	url='https://wsricardo.blogspot.com',
	#packages=['distutils', 'distutils.command'],
	py_modules=['genvideo',]
)
